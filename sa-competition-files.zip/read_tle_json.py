#!/usr/bin/env python3
"""
Script to read JSON files containing TLE (Two-Line Element) data and display
the formatted three-line element sets.

The script looks for TLE_LINE0, TLE_LINE1, and TLE_LINE2 fields in each JSON entry
and formats them as proper TLE sets for use with SGP4 propagators.
"""

import json
import sys
import os
import argparse

def read_tle_json(filename):
    """
    Read a JSON file and extract TLE data from each entry.
    
    Args:
        filename (str): Path to the JSON file
        
    Returns:
        list: List of dictionaries containing TLE data for each entry
    """
    try:
        with open(filename, 'r') as f:
            data = json.load(f)
        
        # Handle both single object and array of objects
        if isinstance(data, dict):
            data = [data]
        
        tle_entries = []
        
        for i, entry in enumerate(data):
            # Check if all required TLE fields exist
            required_fields = ['TLE_LINE0', 'TLE_LINE1', 'TLE_LINE2']
            if all(field in entry for field in required_fields):
                tle_data = {
                    'entry_index': i,
                    'object_name': entry.get('OBJECT_NAME', f'Entry_{i}'),
                    'norad_id': entry.get('NORAD_CAT_ID', 'Unknown'),
                    'tle_line0': entry['TLE_LINE0'],
                    'tle_line1': entry['TLE_LINE1'],
                    'tle_line2': entry['TLE_LINE2']
                }
                tle_entries.append(tle_data)
            else:
                missing_fields = [field for field in required_fields if field not in entry]
                print(f"Warning: Entry {i} missing TLE fields: {missing_fields}")
        
        return tle_entries
        
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        return []
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON format in '{filename}': {e}")
        return []
    except Exception as e:
        print(f"Error reading file '{filename}': {e}")
        return []

def display_tle_sets(tle_entries):
    """
    Display the TLE sets in a formatted manner.
    
    Args:
        tle_entries (list): List of TLE data dictionaries
    """
    if not tle_entries:
        print("No TLE data found in the JSON file.")
        return
    
    print(f"Found {len(tle_entries)} TLE entries in the JSON file.")
    print("=" * 80)
    
    for entry in tle_entries:
        print(f"\nTLE Set #{entry['entry_index'] + 1} - {entry['object_name']} (NORAD ID: {entry['norad_id']})")
        print("-" * 60)
        print(entry['tle_line0'])
        print(entry['tle_line1'])
        print(entry['tle_line2'])
        print()

def save_tle_to_file(tle_entries, output_filename):
    """
    Save TLE sets to a .tle file in the standard TLE format.
    
    Args:
        tle_entries (list): List of TLE data dictionaries
        output_filename (str): Output filename (will add .tle extension if not present)
        
    Returns:
        bool: True if successful, False otherwise
    """
    if not tle_entries:
        print("No TLE data to save.")
        return False
    
    # Ensure the filename has .tle extension
    if not output_filename.endswith('.tle'):
        output_filename += '.tle'
    
    try:
        with open(output_filename, 'w') as f:
            for entry in tle_entries:
                # Write the three lines of the TLE set
                f.write(entry['tle_line0'] + '\n')
                f.write(entry['tle_line1'] + '\n')
                f.write(entry['tle_line2'] + '\n')
        
        print(f"Successfully saved {len(tle_entries)} TLE sets to '{output_filename}'")
        return True
        
    except Exception as e:
        print(f"Error saving TLE file '{output_filename}': {e}")
        return False

def main():
    """Main function to execute the script."""
    parser = argparse.ArgumentParser(
        description='Read JSON files containing TLE data and display formatted three-line element sets.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python read_tle_json.py sample-gp-history.json
  python read_tle_json.py /path/to/your/tle-data.json
  python read_tle_json.py sample-gp-history.json --output oneweb-tle
  python read_tle_json.py sample-gp-history.json -o oneweb-tle -v
        """
    )
    
    parser.add_argument('json_file', 
                       help='Path to the JSON file containing TLE data')
    
    parser.add_argument('--verbose', '-v', 
                       action='store_true',
                       help='Show additional information about each TLE entry')
    
    parser.add_argument('--output', '-o',
                       type=str,
                       help='Output filename for .tle file (without extension)')
    
    args = parser.parse_args()
    
    # Check if file exists
    if not os.path.exists(args.json_file):
        print(f"Error: File '{args.json_file}' does not exist.")
        sys.exit(1)
    
    print("TLE JSON Reader")
    print("=" * 50)
    print(f"Reading JSON file: {args.json_file}")
    
    # Read and process the JSON file
    tle_entries = read_tle_json(args.json_file)
    
    if tle_entries:
        display_tle_sets(tle_entries)
        
        # Save to .tle file if output filename is provided
        if args.output:
            save_tle_to_file(tle_entries, args.output)
        
        if args.verbose:
            print("\nDetailed Information:")
            print("=" * 50)
            for entry in tle_entries:
                print(f"\nEntry {entry['entry_index'] + 1}:")
                print(f"  Object Name: {entry['object_name']}")
                print(f"  NORAD ID: {entry['norad_id']}")
                print(f"  TLE Line 0: {entry['tle_line0']}")
                print(f"  TLE Line 1: {entry['tle_line1']}")
                print(f"  TLE Line 2: {entry['tle_line2']}")
    else:
        print("No valid TLE data found in the JSON file.")
        sys.exit(1)

if __name__ == "__main__":
    main()
