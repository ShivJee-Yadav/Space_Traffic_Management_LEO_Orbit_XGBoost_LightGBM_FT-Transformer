# Space Analytics Competition - Python Scripts

This directory contains Python scripts for analyzing space data, including collision events and satellite orbital elements (TLEs).

## Prerequisites

Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Scripts Overview

### 1. Excel Data Reader (`read_excel_data.py`)

Reads Excel workbooks containing collision event data and creates pandas DataFrames.

**Features:**
- Reads 6 Excel files with collision event data
- Parses column headers from `headers.txt`
- Creates DataFrames named after Excel files
- Handles 22 columns of collision data

**Usage:**
```bash
python read_excel_data.py
```

**Output:**
- Creates 6 DataFrames: `CZ_6A_Events_2024-08-06`, `CZ_6A_Events_2024-09-06`, etc.
- Each DataFrame contains collision events with 22 columns
- DataFrames are available in the `dataframes` dictionary

**Example:**
```python
from read_excel_data import main
dataframes = main()
df_2024_08 = dataframes['CZ_6A_Events_2024-08-06']
print(df_2024_08.head())
```

### 2. Excel Data Analysis (`example_usage.py`)

Demonstrates analysis of collision event data from Excel files.

**Features:**
- Access specific DataFrames
- Filter high-probability collision events
- Group by object type
- Find top 10 highest probability events

**Usage:**
```bash
python example_usage.py
```

**Key Analysis:**
- Filters events with collision probability > 1e-5
- Ranks events by probability (highest to lowest)
- Shows detailed information for top events
- Displays primary and secondary object details

### 3. TLE JSON Reader (`read_tle_json.py`)

Reads JSON files containing TLE (Two-Line Element) data and formats them for satellite propagation.

**Features:**
- Extracts TLE_LINE0, TLE_LINE1, TLE_LINE2 from JSON
- Displays formatted three-line element sets
- Saves TLE data to .tle files
- Handles both single objects and arrays

**Usage:**
```bash
# Basic usage
python read_tle_json.py sample-gp-history.json

# Save to TLE file
python read_tle_json.py sample-gp-history.json --output oneweb-tle

# Verbose mode
python read_tle_json.py sample-gp-history.json --verbose

# Short form
python read_tle_json.py sample-gp-history.json -o oneweb-tle -v
```

**Command Line Options:**
- `--output`, `-o`: Output filename for .tle file (without extension)
- `--verbose`, `-v`: Show additional information about each TLE entry

**Example Output:**
```
TLE Set #1 - ONEWEB-0355 (NORAD ID: 49218)
------------------------------------------------------------
0 ONEWEB-0355
1 49218U 21083AJ  24228.92048886  .00000343  00000-0  90339-3 0  9998
2 49218  87.8886  93.6498 0001676  84.7123 275.4198 13.13470594144210
```

### 4. TLE Propagator (`tle_propagator.py`)

Reads TLE files and propagates satellite orbits using astropy and SGP4.

**Features:**
- Accurate TLE epoch parsing
- SGP4 orbital propagation
- Configurable duration and time steps
- Position, velocity, altitude, and speed calculations
- Summary statistics

**Usage:**
```bash
# Basic 3-day propagation
python tle_propagator.py oneweb-tle.tle

# Custom duration and time step
python tle_propagator.py oneweb-tle.tle --duration 7 --step 2

# Show all time points
python tle_propagator.py oneweb-tle.tle --show-all

# Short form
python tle_propagator.py oneweb-tle.tle -d 1 -s 0.5 -a
```

**Command Line Options:**
- `--duration`, `-d`: Propagation duration in days (default: 3)
- `--step`, `-s`: Time step between propagation points in hours (default: 1)
- `--show-all`, `-a`: Show all time points instead of summary

**Example Output:**
```
TLE Epoch: 2024-08-15 22:05:30.238
Propagating for 3.0 days with 1.0-hour steps...

Propagation Results (72 time points):
================================================================================
Time (UTC)           X (km)       Y (km)       Z (km)       Alt (km)   Speed (km/s)
--------------------------------------------------------------------------------
2024-08-15 22:05:30  -483.207     7575.277     0.010        1219.672   7.248
2024-08-16 10:05:30  542.203      -6961.840    -2984.347    1222.914   7.244
2024-08-17 21:05:30  536.239      -6612.687    -3696.131    1223.509   7.242

Summary Statistics:
  Altitude range: 1208.479 - 1225.642 km
  Speed range: 7.234 - 7.251 km/s
  Mean altitude: 1218.623 km
  Mean speed: 7.245 km/s
```

### 5. TLE Example (`tle_example.py`)

Demonstrates programmatic usage of the TLE JSON reader.

**Usage:**
```bash
python tle_example.py
```

**Features:**
- Shows how to access TLE data programmatically
- Demonstrates different analysis approaches
- Counts unique objects and provides summaries

### 6. TLE Propagation Example (`tle_propagation_example.py`)

Demonstrates programmatic usage of the TLE propagator.

**Usage:**
```bash
python tle_propagation_example.py
```

**Features:**
- Multiple propagation scenarios
- Orbital analysis and statistics
- High-resolution and long-duration examples

## Data Files

### Excel Files
- `CZ_6A_Events_2024-08-06.xlsx` through `CZ_6A_Events_2025-08-06.xlsx`
- Contains collision event data with 22 columns
- Headers defined in `headers.txt`

### JSON Files
- `sample-gp-history.json` - Sample TLE data in JSON format
- `sample-gp-history-pretty.json` - Pretty-formatted version

### Generated Files
- `*.tle` - TLE files created by the JSON reader
- `oneweb-tle.tle` - Example TLE file from sample data

## Column Headers (from headers.txt)

The Excel files contain the following 22 columns:

1. `cdmMissDistance` - Miss Distance (km)
2. `cdmPc` - Probability of collision (Foster)
3. `creationTsOfCDM` - CDM creation time stamp
4. `SAT1_CDM_TYPE` - Screening type for primary object
5. `SAT2_CDM_TYPE` - Screening type for secondary object
6. `cdmTca` - Time of closest approach
7. `rso1_noradId` - Primary object NORAD ID
8. `rso1_objectType` - Primary object type
9. `org1_displayName` - Operator
10. `rso2_noradId` - Secondary object NORAD ID
11. `rso2_objectType` - Secondary object type
12. `org2_displayName` - Secondary object operator
13. `condition_cdmType=EPHEM:HAC` - Screening type condition
14. `condition_24H<tca<72H` - Time window condition
15. `condition_Pc>1e-6` - Probability threshold condition
16. `condition_missDistance<2000m` - Miss distance condition
17. `condition_Radial<100m` - Radial position condition
18. `condition_Radial<50m` - Tight radial condition
19. `condition_InTrack<500m` - In-track position condition
20. `condition_CrossTrack<500m` - Cross-track position condition
21. `condition_sat2posUnc>1km` - Position uncertainty condition
22. `condition_sat2Obs<25` - Observation count condition

## Dependencies

See `requirements.txt` for the complete list:

- `pandas>=1.3.0` - Data manipulation
- `openpyxl>=3.0.0` - Excel file reading
- `astropy>=5.0.0` - Astronomical calculations
- `sgp4>=2.0.0` - Satellite propagation

## Installation

1. Clone or download this directory
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the scripts as shown in the usage examples above

## Notes

- All scripts are designed to work with the provided sample data
- TLE propagation uses accurate epoch parsing (fixed bug in original SGP4 library)
- Excel files are read in alphabetical order for consistent processing
- All scripts include comprehensive error handling and help documentation
