#!/usr/bin/env python3
"""
Script to read TLE files and propagate satellite orbits using astropy.

This script reads a .tle file, extracts the first TLE set, and propagates
the satellite orbit for a specified duration using astropy's SGP4 propagator.
"""

import argparse
import sys
import os
from datetime import datetime, timedelta
import numpy as np

try:
    from astropy.coordinates import EarthLocation, ITRS
    from astropy.time import Time
    from astropy import units as u
    from sgp4.api import Satrec
    from sgp4.api import jday
except ImportError as e:
    print(f"Error: Required packages not installed. Please install astropy and sgp4:")
    print(f"  pip install astropy sgp4")
    print(f"Missing: {e}")
    sys.exit(1)

def read_tle_file(filename):
    """
    Read a TLE file and extract the first TLE set.
    
    Args:
        filename (str): Path to the .tle file
        
    Returns:
        tuple: (line0, line1, line2) or None if error
    """
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
        
        # Remove empty lines and strip whitespace
        lines = [line.strip() for line in lines if line.strip()]
        
        if len(lines) < 3:
            print(f"Error: TLE file must contain at least 3 lines (one TLE set)")
            return None
        
        # Extract the first TLE set (3 lines)
        line0 = lines[0]
        line1 = lines[1]
        line2 = lines[2]
        
        print(f"Successfully read TLE file: {filename}")
        print(f"TLE Set:")
        print(f"  Line 0: {line0}")
        print(f"  Line 1: {line1}")
        print(f"  Line 2: {line2}")
        
        return line0, line1, line2
        
    except FileNotFoundError:
        print(f"Error: TLE file '{filename}' not found.")
        return None
    except Exception as e:
        print(f"Error reading TLE file '{filename}': {e}")
        return None

def propagate_tle(tle_lines, duration_days=3, time_step_hours=1):
    """
    Propagate a TLE set for the specified duration.
    
    Args:
        tle_lines (tuple): (line0, line1, line2) TLE data
        duration_days (float): Duration to propagate in days
        time_step_hours (float): Time step between propagation points in hours
        
    Returns:
        list: List of (time, position, velocity) tuples
    """
    line0, line1, line2 = tle_lines
    
    # Create satellite object from TLE
    satellite = Satrec.twoline2rv(line1, line2)
    
    # Parse the TLE epoch manually for accurate time
    # Extract the epoch from line 1 (characters 18-32)
    tle_epoch_str = line1[18:32]  # "24228.92048886"
    
    try:
        tle_epoch_float = float(tle_epoch_str)
        tle_year = int(tle_epoch_float // 1000)
        tle_day_of_year = int(tle_epoch_float % 1000)
        tle_fraction = tle_epoch_float % 1
        
        # Handle 2-digit years (add 2000 if year < 50)
        tle_year += 2000
        
        # Convert to datetime
        from datetime import datetime, timedelta
        base_date = datetime(tle_year, 1, 1)
        epoch_date = base_date + timedelta(days=tle_day_of_year - 1 + tle_fraction)
        
        # Use the manually parsed epoch for propagation
        epoch_time = Time(epoch_date)
        print(f"\nTLE Epoch: {epoch_time.iso}")
        
    except Exception as e:
        print(f"Error parsing TLE epoch: {e}")
        # Fallback to SGP4 epoch (may be less accurate)
        epoch_jd = satellite.jdsatepoch
        epoch_time = Time(epoch_jd, format='jd')
        print(f"\nTLE Epoch (SGP4 fallback): {epoch_time.iso}")
    
    print(f"Propagating for {duration_days} days with {time_step_hours}-hour steps...")
    
    # Generate time points for propagation
    time_points = []
    current_time = epoch_time
    end_time = epoch_time + timedelta(days=duration_days)
    
    while current_time <= end_time:
        time_points.append(current_time)
        current_time += timedelta(hours=time_step_hours)
    
    # Propagate at each time point
    results = []
    for i, time in enumerate(time_points):
        # Convert to Julian day for SGP4
        jd = time.jd
        
        # Propagate using SGP4
        error, position, velocity = satellite.sgp4(jd, 0.0)
        
        if error != 0:
            print(f"Warning: SGP4 error {error} at time {time.iso}")
            continue
        
        # Convert position to ITRS (Earth-fixed coordinates)
        # SGP4 returns position in km, convert to meters
        position_km = np.array(position)  # km
        velocity_km_s = np.array(velocity)  # km/s
        
        # Store results
        results.append({
            'time': time,
            'position_km': position_km,
            'velocity_km_s': velocity_km_s,
            'altitude_km': np.linalg.norm(position_km) - 6371.0,  # Earth radius ~6371 km
            'speed_km_s': np.linalg.norm(velocity_km_s)
        })
    
    return results

def display_propagation_results(results, show_all=False):
    """
    Display the propagation results in a formatted manner.
    
    Args:
        results (list): List of propagation results
        show_all (bool): If True, show all time points; if False, show summary
    """
    if not results:
        print("No propagation results to display.")
        return
    
    print(f"\nPropagation Results ({len(results)} time points):")
    print("=" * 80)
    
    if show_all:
        # Show all time points
        print(f"{'Time (UTC)':<20} {'X (km)':<12} {'Y (km)':<12} {'Z (km)':<12} {'Alt (km)':<10} {'Speed (km/s)':<12}")
        print("-" * 80)
        
        for result in results:
            time_str = result['time'].iso.replace('T', ' ')[:19]
            pos = result['position_km']
            print(f"{time_str:<20} {pos[0]:<12.3f} {pos[1]:<12.3f} {pos[2]:<12.3f} "
                  f"{result['altitude_km']:<10.3f} {result['speed_km_s']:<12.3f}")
    else:
        # Show summary with first, middle, and last points
        print(f"{'Time (UTC)':<20} {'X (km)':<12} {'Y (km)':<12} {'Z (km)':<12} {'Alt (km)':<10} {'Speed (km/s)':<12}")
        print("-" * 80)
        
        # First point
        result = results[0]
        time_str = result['time'].iso.replace('T', ' ')[:19]
        pos = result['position_km']
        print(f"{time_str:<20} {pos[0]:<12.3f} {pos[1]:<12.3f} {pos[2]:<12.3f} "
              f"{result['altitude_km']:<10.3f} {result['speed_km_s']:<12.3f}")
        
        # Middle point (if more than 2 points)
        if len(results) > 2:
            mid_idx = len(results) // 2
            result = results[mid_idx]
            time_str = result['time'].iso.replace('T', ' ')[:19]
            pos = result['position_km']
            print(f"{time_str:<20} {pos[0]:<12.3f} {pos[1]:<12.3f} {pos[2]:<12.3f} "
                  f"{result['altitude_km']:<10.3f} {result['speed_km_s']:<12.3f}")
        
        # Last point
        result = results[-1]
        time_str = result['time'].iso.replace('T', ' ')[:19]
        pos = result['position_km']
        print(f"{time_str:<20} {pos[0]:<12.3f} {pos[1]:<12.3f} {pos[2]:<12.3f} "
              f"{result['altitude_km']:<10.3f} {result['speed_km_s']:<12.3f}")
    
    # Summary statistics
    altitudes = [r['altitude_km'] for r in results]
    speeds = [r['speed_km_s'] for r in results]
    
    print(f"\nSummary Statistics:")
    print(f"  Altitude range: {min(altitudes):.3f} - {max(altitudes):.3f} km")
    print(f"  Speed range: {min(speeds):.3f} - {max(speeds):.3f} km/s")
    print(f"  Mean altitude: {np.mean(altitudes):.3f} km")
    print(f"  Mean speed: {np.mean(speeds):.3f} km/s")

def main():
    """Main function to execute the script."""
    parser = argparse.ArgumentParser(
        description='Read TLE files and propagate satellite orbits using astropy.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python tle_propagator.py oneweb-tle.tle
  python tle_propagator.py oneweb-tle.tle --duration 7 --step 2
  python tle_propagator.py oneweb-tle.tle --show-all
        """
    )
    
    parser.add_argument('tle_file', 
                       help='Path to the .tle file containing TLE data')
    
    parser.add_argument('--duration', '-d',
                       type=float,
                       default=3.0,
                       help='Propagation duration in days (default: 3)')
    
    parser.add_argument('--step', '-s',
                       type=float,
                       default=1.0,
                       help='Time step between propagation points in hours (default: 1)')
    
    parser.add_argument('--show-all', '-a',
                       action='store_true',
                       help='Show all time points instead of summary')
    
    args = parser.parse_args()
    
    # Check if file exists
    if not os.path.exists(args.tle_file):
        print(f"Error: TLE file '{args.tle_file}' does not exist.")
        sys.exit(1)
    
    print("TLE Propagator")
    print("=" * 50)
    print(f"TLE file: {args.tle_file}")
    print(f"Duration: {args.duration} days")
    print(f"Time step: {args.step} hours")
    
    # Read TLE file
    tle_lines = read_tle_file(args.tle_file)
    if not tle_lines:
        sys.exit(1)
    
    # Propagate orbit
    results = propagate_tle(tle_lines, args.duration, args.step)
    
    if not results:
        print("No propagation results generated.")
        sys.exit(1)
    
    # Display results
    display_propagation_results(results, args.show_all)

if __name__ == "__main__":
    main()
