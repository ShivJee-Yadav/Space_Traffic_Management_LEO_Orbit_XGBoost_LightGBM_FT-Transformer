#!/usr/bin/env python3
"""
Script to read Excel workbooks into pandas DataFrames.
Each Excel file will be loaded into a DataFrame named after the file (minus extension).
"""

import pandas as pd
import os
import glob

def parse_headers(headers_file):
    """
    Parse the headers.txt file to extract column names and definitions.
    
    Args:
        headers_file (str): Path to the headers.txt file
        
    Returns:
        list: List of column names
    """
    column_names = []
    
    with open(headers_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):  # Skip empty lines and comments
                # Split by comma and take the first part (header name)
                header_name = line.split(',')[0].strip().strip('"')
                column_names.append(header_name)
    
    return column_names

def read_excel_files(directory_path):
    """
    Read all Excel files in the directory and create pandas DataFrames.
    
    Args:
        directory_path (str): Path to the directory containing Excel files
        
    Returns:
        dict: Dictionary with DataFrame names as keys and DataFrames as values
    """
    # Parse headers
    headers_file = os.path.join(directory_path, 'headers.txt')
    column_names = parse_headers(headers_file)
    
    print(f"Found {len(column_names)} column headers:")
    for i, col in enumerate(column_names, 1):
        print(f"  {i}. {col}")
    
    # Find all Excel files and sort them alphabetically
    excel_files = glob.glob(os.path.join(directory_path, '*.xlsx'))
    excel_files = [f for f in excel_files if not f.endswith('~$')]  # Exclude temp files
    excel_files.sort()  # Sort alphabetically
    
    print(f"\nFound {len(excel_files)} Excel files:")
    for file in excel_files:
        print(f"  - {os.path.basename(file)}")
    
    # Dictionary to store DataFrames
    dataframes = {}
    
    # Read each Excel file
    for excel_file in excel_files:
        # Get filename without extension for DataFrame name
        filename = os.path.basename(excel_file)
        df_name = os.path.splitext(filename)[0]
        
        print(f"\nReading {filename}...")
        
        try:
            # Read Excel file
            df = pd.read_excel(excel_file, header=0)
            
            # Set column names from headers.txt
            if len(df.columns) == len(column_names):
                df.columns = column_names
                print(f"  ✓ Successfully loaded with {len(df)} rows and {len(df.columns)} columns")
            else:
                print(f"  ⚠ Warning: Column count mismatch. Expected {len(column_names)}, got {len(df.columns)}")
                print(f"  Using original column names from Excel file")
            
            # Store DataFrame in dictionary
            dataframes[df_name] = df
            
        except Exception as e:
            print(f"  ✗ Error reading {filename}: {str(e)}")
    
    return dataframes

def main():
    """Main function to execute the script."""
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("Excel to DataFrame Reader")
    print("=" * 50)
    
    # Read all Excel files
    dataframes = read_excel_files(script_dir)
    
    print(f"\n" + "=" * 50)
    print(f"Successfully created {len(dataframes)} DataFrames:")
    
    for df_name, df in dataframes.items():
        print(f"  - {df_name}: {df.shape[0]} rows × {df.shape[1]} columns")
    
    print(f"\nDataFrames are available in the 'dataframes' dictionary.")
    print(f"You can access them like: dataframes['CZ_6A_Events_2024-08-06']")
    
    # Example of how to access the DataFrames
    print(f"\nExample usage:")
    print(f"  df_2024_08 = dataframes['CZ_6A_Events_2024-08-06']")
    print(f"  print(df_2024_08.head())")
    
    return dataframes

if __name__ == "__main__":
    # Execute the main function
    dataframes = main()
    
    # Make dataframes available in global scope for interactive use
    globals().update(dataframes)
