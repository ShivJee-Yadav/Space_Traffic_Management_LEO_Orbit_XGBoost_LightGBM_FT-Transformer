#!/usr/bin/env python3
"""
Example script showing how to use the DataFrames created by read_excel_data.py
"""

from read_excel_data import main

# Load all DataFrames
dataframes = main()

# Example 1: Access a specific DataFrame
print("Example 1: Accessing a specific DataFrame")
print("=" * 50)
df_2024_08_06 = dataframes['CZ_6A_Events_2024-08-06']
print(f"DataFrame shape: {df_2024_08_06.shape}")
print(f"Columns: {list(df_2024_08_06.columns)}")
print("\nFirst 5 rows:")
print(df_2024_08_06.head())

# Example 2: Basic statistics
print("\n\nExample 2: Basic statistics")
print("=" * 50)
print("Row counts for each DataFrame:")
for name, df in dataframes.items():
    print(f"  {name}: {len(df)} rows")

# Example 3: Filter data
print("\n\nExample 3: Filtering data for 2024-08-06")
print("=" * 50)
# Filter for high probability collisions (Pc > 1e-5)
high_prob_df = df_2024_08_06[df_2024_08_06['cdmPc'] > 1e-5]
print(f"High probability collisions (Pc > 1e-5): {len(high_prob_df)} events")

# Example 4: Group by object type
print("\n\nExample 4: Group by object type for 2024-08-06")
print("=" * 50)
object_type_counts = df_2024_08_06['rso1_objectType'].value_counts()
print("Primary object type distribution:")
print(object_type_counts)

# Example 5: Access all DataFrames
print("\n\nExample 5: All available DataFrames")
print("=" * 50)
print("Available DataFrames:")
for name in dataframes.keys():
    print(f"  - {name}")

# Example 6: Top 10 highest probability collision events
print("\n\nExample 6: Top 10 highest probability collision events (cdmPc > 1e-5)")
print("=" * 80)
# Filter for high probability collisions and sort by cdmPc in descending order
high_prob_events = df_2024_08_06[df_2024_08_06['cdmPc'] > 1e-5].copy()
high_prob_events_sorted = high_prob_events.sort_values('cdmPc', ascending=False)

print(f"Total high probability events (cdmPc > 1e-5): {len(high_prob_events_sorted)}")
print(f"\nTop 10 highest probability collision events:")
print("-" * 80)

# Display top 10 events with key information
top_10 = high_prob_events_sorted.head(10)
for i, (idx, row) in enumerate(top_10.iterrows(), 1):
    print(f"{i:2d}. cdmPc: {row['cdmPc']:.2e} | "
          f"Miss Distance: {row['cdmMissDistance']:.2f} km | "
          f"TCA: {row['cdmTca']} | "
          f"Primary: {row['rso1_noradId']} ({row['rso1_objectType']}) - {row['org1_displayName']} | "
          f"Secondary: {row['rso2_noradId']} ({row['rso2_objectType']}) - {row['org2_displayName']}")

print(f"\nDetailed view of the top 3 events:")
print("-" * 80)
for i, (idx, row) in enumerate(top_10.head(3).iterrows(), 1):
    print(f"\nEvent #{i} (cdmPc: {row['cdmPc']:.2e}):")
    print(f"  Primary Object: NORAD ID {row['rso1_noradId']} ({row['rso1_objectType']}) - {row['org1_displayName']}")
    print(f"  Secondary Object: NORAD ID {row['rso2_noradId']} ({row['rso2_objectType']}) - {row['org2_displayName']}")
    print(f"  Miss Distance: {row['cdmMissDistance']:.2f} km")
    print(f"  Time of Closest Approach: {row['cdmTca']}")
    print(f"  CDM Creation Time: {row['creationTsOfCDM']}")
    print(f"  Screening Type: {row['SAT1_CDM_TYPE']} / {row['SAT2_CDM_TYPE']}")
