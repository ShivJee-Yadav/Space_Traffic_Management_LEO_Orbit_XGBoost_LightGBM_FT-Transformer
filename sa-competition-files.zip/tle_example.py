#!/usr/bin/env python3
"""
Example script showing how to use the TLE JSON reader programmatically.
"""

from read_tle_json import read_tle_json

def main():
    """Example usage of the TLE JSON reader."""
    print("TLE JSON Reader - Programmatic Usage Example")
    print("=" * 60)
    
    # Read the sample JSON file
    filename = "sample-gp-history.json"
    tle_entries = read_tle_json(filename)
    
    if tle_entries:
        print(f"Successfully loaded {len(tle_entries)} TLE entries from {filename}")
        
        # Example 1: Display all TLE sets
        print("\n1. All TLE Sets:")
        print("-" * 40)
        for i, entry in enumerate(tle_entries):
            print(f"\nTLE #{i+1} - {entry['object_name']} (NORAD: {entry['norad_id']})")
            print(entry['tle_line0'])
            print(entry['tle_line1'])
            print(entry['tle_line2'])
        
        # Example 2: Extract just the TLE lines for SGP4 propagation
        print("\n\n2. TLE Lines for SGP4 Propagation:")
        print("-" * 40)
        for i, entry in enumerate(tle_entries[:3]):  # Show first 3
            print(f"\nTLE Set #{i+1}:")
            print(f"  Line 0: {entry['tle_line0']}")
            print(f"  Line 1: {entry['tle_line1']}")
            print(f"  Line 2: {entry['tle_line2']}")
        
        # Example 3: Count unique objects
        unique_objects = set(entry['object_name'] for entry in tle_entries)
        print(f"\n\n3. Summary:")
        print(f"  Total TLE entries: {len(tle_entries)}")
        print(f"  Unique objects: {len(unique_objects)}")
        print(f"  Objects: {', '.join(unique_objects)}")
        
    else:
        print(f"No TLE data found in {filename}")

if __name__ == "__main__":
    main()
