#!/usr/bin/env python3
"""
Example script showing how to use the TLE propagator programmatically.
"""

from tle_propagator import read_tle_file, propagate_tle, display_propagation_results

def main():
    """Example usage of the TLE propagator."""
    print("TLE Propagator - Programmatic Usage Example")
    print("=" * 60)
    
    # Read the TLE file
    tle_file = "oneweb-tle.tle"
    tle_lines = read_tle_file(tle_file)
    
    if not tle_lines:
        print(f"Failed to read TLE file: {tle_file}")
        return
    
    # Example 1: Short propagation (1 day, 2-hour steps)
    print("\n1. Short Propagation (1 day, 2-hour steps):")
    print("-" * 50)
    results_short = propagate_tle(tle_lines, duration_days=1.0, time_step_hours=2.0)
    display_propagation_results(results_short, show_all=False)
    
    # Example 2: Longer propagation (7 days, 6-hour steps)
    print("\n\n2. Longer Propagation (7 days, 6-hour steps):")
    print("-" * 50)
    results_long = propagate_tle(tle_lines, duration_days=7.0, time_step_hours=6.0)
    display_propagation_results(results_long, show_all=False)
    
    # Example 3: High-resolution propagation (12 hours, 15-minute steps)
    print("\n\n3. High-Resolution Propagation (12 hours, 15-minute steps):")
    print("-" * 50)
    results_hr = propagate_tle(tle_lines, duration_days=0.5, time_step_hours=0.25)
    display_propagation_results(results_hr, show_all=False)
    
    # Example 4: Analyze orbital characteristics
    print("\n\n4. Orbital Analysis:")
    print("-" * 50)
    if results_long:
        altitudes = [r['altitude_km'] for r in results_long]
        speeds = [r['speed_km_s'] for r in results_long]
        
        print(f"Orbital Period Analysis (7-day propagation):")
        print(f"  Minimum altitude: {min(altitudes):.3f} km")
        print(f"  Maximum altitude: {max(altitudes):.3f} km")
        print(f"  Altitude variation: {max(altitudes) - min(altitudes):.3f} km")
        print(f"  Mean altitude: {sum(altitudes)/len(altitudes):.3f} km")
        print(f"  Minimum speed: {min(speeds):.3f} km/s")
        print(f"  Maximum speed: {max(speeds):.3f} km/s")
        print(f"  Speed variation: {max(speeds) - min(speeds):.3f} km/s")
        print(f"  Mean speed: {sum(speeds)/len(speeds):.3f} km/s")

if __name__ == "__main__":
    main()
